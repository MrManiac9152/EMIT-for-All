package com.example.afe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.roger.gifloadinglibrary.GifLoadingView;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {
    private GifLoadingView mGifLoadingView;

    CardView location_layout;
    private static final String TAG = "MainActivity";
    RelativeLayout btn_location;
//    ACProgressFlower mGifLoadingView;
    private WebView simpleWebView;

    String URL_FOR_BACK="";
    String Url="file:///android_asset/index.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_location=findViewById(R.id.btn_location);
        location_layout=findViewById(R.id.location_layout);
        overridePendingTransition(R.anim.do_not_move, R.anim.do_not_move);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
        location_layout.setVisibility(View.GONE);
        btn_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheetSelectLocation bottomSheetDialog = BottomSheetSelectLocation.newInstance();
                bottomSheetDialog.show(getSupportFragmentManager(),"Bottom Sheet Dialog Fragment");

            }
        });
        simpleWebView = (WebView)findViewById(R.id.myWebView);

        // loader Start
//        mGifLoadingView = new ACProgressFlower.Builder(this)
//                .direction(ACProgressConstant.DIRECT_CLOCKWISE)
//                .themeColor(Color.WHITE)
//                .fadeColor(Color.BLACK).build();
//        mGifLoadingView.show();
        mGifLoadingView = new GifLoadingView();
        mGifLoadingView.setImageResource(R.drawable.giphy_s);
        mGifLoadingView.show(getFragmentManager());
        /*Add in Oncreate() funtion after setContentView()*/
// initiate a web view

// set web view client
        simpleWebView.setWebViewClient(new MyWebViewClient());

// string url which you have to load into a web view
        simpleWebView.getSettings().setJavaScriptEnabled(true);
        simpleWebView.loadUrl(Url); // load the url on the web view

    }



    public void refreshAfterSelecClass(String link) {

//        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

//        WebSettings webSettings = simpleWebView.getSettings();
//        webSettings.setAllowFileAccess(true);
//        webSettings.setBuiltInZoomControls(false);
//        webSettings.setJavaScriptEnabled(true);
//        simpleWebView.getSettings().setAllowContentAccess(true);
//        simpleWebView.getSettings().setAllowFileAccess(true);
//        simpleWebView.setWebViewClient(new Callback());
//        simpleWebView.loadUrl(link);
//        simpleWebView.setHorizontalScrollBarEnabled(false);
//        simpleWebView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        simpleWebView.loadUrl(link); // load the url on the web view

    }
    @Override
    public void onBackPressed() {
//        Log.e(TAG, "shouldOverrideUrlLoading: URL ::"+url );

//        if(URL_FOR_BACK.equalsIgnoreCase("file:///android_asset/location.html")){
//            btn_location.setVisibility(View.VISIBLE);
//        }else {
        location_layout.setVisibility(View.GONE);

//        }
        if (simpleWebView != null && simpleWebView.canGoBack()) {
            simpleWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Log.e(TAG, "shouldOverrideUrlLoading: URL ::"+url );
            if(url.equalsIgnoreCase("file:///android_asset/location.html")){
                location_layout.setVisibility(View.VISIBLE);

            }else {
                location_layout.setVisibility(View.GONE);

            }
            if(!mGifLoadingView.isVisible()){
                mGifLoadingView = new GifLoadingView();
                mGifLoadingView.setImageResource(R.drawable.giphy_s);
                mGifLoadingView.show(getFragmentManager());
            }

            URL_FOR_BACK=url;
            view.loadUrl(url); // load the url
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            Log.e(TAG, "shouldOverrideUrlLoading: FURL ::"+Url );

            mGifLoadingView.dismiss();


        }

    }

}