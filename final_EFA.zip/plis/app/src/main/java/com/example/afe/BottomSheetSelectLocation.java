package com.example.afe;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import javax.security.auth.callback.Callback;

public class BottomSheetSelectLocation extends BottomSheetDialogFragment {
    public Callback mCallback;

    RelativeLayout btn_now,btn_later;
    public static BottomSheetSelectLocation newInstance() {
        return new BottomSheetSelectLocation();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return super.onCreateDialog(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.botton_sheet_select_location, container,false);
        btn_now=view.findViewById(R.id.btn_now);
        btn_later=view.findViewById(R.id.btn_later);




        btn_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
//                SharedPreferences sp = requireActivity().getSharedPreferences(Constant.USER_PREF, Context.MODE_PRIVATE);
//                SharedPreferences.Editor editor = sp.edit();
//                editor.putString(Constant.RIDE_TYPE,"Now");
//                editor.apply();
                ((MainActivity) requireActivity()).refreshAfterSelecClass("https://earth.jpl.nasa.gov/emit-mmgis-lb/?mission=EMIT&site=ert&mapLon=78.8718E&mapLat=21.7679N&mapZoom=5&globeLon=78.8718E&globeLat=21.7679N&globeZoom=2&globeCamera=0,-10000000,10.000000999998331,0,1,0&panePercents=0,100,0&on=8fed617c-0c4e-4841-87d1-f4ffd1a56d4e$1.00,37414e25-e3d3-4b78-ade5-75edfe4e5da0$1.00,ba365157-1ba0-4c7e-9a3a-4bce7ad3ed13$0.70");

            }
        });
        btn_later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
//                SharedPreferences sp = requireActivity().getSharedPreferences(Constant.USER_PREF, Context.MODE_PRIVATE);
//                SharedPreferences.Editor editor = sp.edit();
//                editor.putString(Constant.RIDE_TYPE,"Later");
//                editor.apply();
                ((MainActivity) requireActivity()).refreshAfterSelecClass("https://earth.jpl.nasa.gov/emit-mmgis-lb/?mission=EMIT&site=ert&mapLon=-98.4842W&mapLat=39.0119N&mapZoom=3&globeLon=0&globeLat=3.508354649267438e-15&globeZoom=2&globeCamera=9.000268457972838,-10000000,10.000298286636488,0,1,0&panePercents=0,100,0&on=8fed617c-0c4e-4841-87d1-f4ffd1a56d4e$1.00,37414e25-e3d3-4b78-ade5-75edfe4e5da0$1.00,ba365157-1ba0-4c7e-9a3a-4bce7ad3ed13$0.70");
            }
        });

        return view;
    }
}
